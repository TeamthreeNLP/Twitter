package team3.twitter.service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import team3.twitter.model.Tweet;
import twitter4j.*; 


public class TwitterCommunication {

	
	// Function to retrieve tweets by user, specify count 
	 public static List<Tweet> searchByUser(String username, int count) {
	        Twitter twitter = new TwitterFactory().getInstance();
	        List<Tweet> results = new ArrayList<>();
	        Paging p = new Paging();
	        p.setCount(count);
	        
	        try {
	            List<Status> statuses;
	            String user = username;       
	            statuses = twitter.getUserTimeline(user,p);
	            System.out.println("Showing @" + user + "'s user timeline.");
	            for (Status status : statuses) {
	            	Tweet tweet = new Tweet(status.getId(), status.getUser().getName(), status.getText(), status.getGeoLocation(), status.getCreatedAt() ,status.getUser().getFollowersCount(), user, count);
//	                System.out.println("@" + status.getUser().getScreenName() + " - " + status.getText());
	                results.add(tweet);
	               
	            }
	        } catch (TwitterException te) {
	            te.printStackTrace();
	            System.out.println("Failed to get timeline: " + te.getMessage());
	            System.exit(-1);
	        }
	        return results;
	    }
	 
	 
	 
	// Function to retrieve tweets by keyword, specify count 
	 
	 public static List<Tweet> searchByKeyword(String keyword, int count) {
		 Twitter twitter = TwitterFactory.getSingleton();
		 List<Tweet> results = new ArrayList<>();
		    Query query = new Query(keyword);
		    query.setCount(count);
		    QueryResult result = null;
			try {
				result = twitter.search(query);
			} catch (TwitterException e) {
				e.printStackTrace();
			}
			
		    for (Status status : result.getTweets()) {
		    Tweet tweet = new Tweet(status.getId(), status.getUser().getName(), status.getText(), status.getGeoLocation(), status.getCreatedAt() ,status.getUser().getFollowersCount(), keyword, count);
//	        System.out.println("@" + status.getUser().getScreenName() + ":" + status.getText());
	        results.add(tweet);
	        
	    }
		    return results;
	 }
	 
	 
	// Function to retrieve tweets by location parameters : Latitude, Longitude , Radius , Count;
	 
	 public static List<Tweet> searchByLocation(double latitude, double longitude, double radius, int count) {
		 Twitter twitter = TwitterFactory.getSingleton();
		 	List<Tweet> results = new ArrayList<>();
		    Query query = new Query("");
		    query.setCount(count);
		    GeoLocation location = new GeoLocation(latitude, longitude);
            query.setGeoCode(location, radius, Query.KILOMETERS);
		    QueryResult result = null;
			try {
				result = twitter.search(query);
			} catch (TwitterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    for (Status status : result.getTweets()) {
	        Tweet tweet = new Tweet(status.getId(), status.getUser().getName(), status.getText(), status.getGeoLocation(), status.getCreatedAt() ,status.getUser().getFollowersCount(), null, count);
	        results.add(tweet);
	        
	    }
		    return results;
	 }
	 
	 
	 
	

	 
	 
	 
	 
}
