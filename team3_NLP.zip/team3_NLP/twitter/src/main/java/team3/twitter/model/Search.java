package team3.twitter.model;

import java.util.List;

public class Search {
	boolean searchByUser;
	boolean searchByKeyword;
	String value;
	int tweetAmount;

	public Search(boolean searchByUser, boolean searchByKeyword, String value,
			int tweetAmount) {
		
		this.searchByUser = searchByUser;
		this.searchByKeyword = searchByKeyword;
		this.value = value;
		this.tweetAmount = tweetAmount;
		
	}
	
	public Search() {
		
	}

	public boolean isSearchByUser() {
		return searchByUser;
	}
	public void setSearchByUser(boolean searchByUser) {
		this.searchByUser = searchByUser;
	}
	
	public boolean isSearchByKeyword() {
		return searchByKeyword;
	}
	public void setSearchByKeyword(boolean searchByKeyword) {
		this.searchByKeyword = searchByKeyword;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public int getTweetAmount() {
		return tweetAmount;
	}
	public void setTweetAmount(int tweetAmount) {
		this.tweetAmount = tweetAmount;
	}
}
