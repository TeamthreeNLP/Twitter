package team3.twitter.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import team3.twitter.service.Analyzer;
import team3.twitter.model.Tweet;
//Imports for tweet4j
import twitter4j.*; 


public class App 

{
	
	
		
		//Analyzes Tweets By Keyword
		public static ArrayList<Tweet>  AnalyzeTweetsByKeyword(String keyword, int count) {
			ArrayList<Tweet> results = new ArrayList<>(TwitterCommunication.searchByKeyword(keyword, count));
			for(Tweet tweet : results) {
				tweet.setSentimentScore(Analyzer.analyse(tweet.getTweetText()));
			}
			return results;
		}
		
		
		
		//Analyzes Tweets By Location
		public static ArrayList<Tweet>  AnalyzeTweetsByLocation(double latitude, double longitude, double radius, int count) {
			ArrayList<Tweet> results = new ArrayList<>(TwitterCommunication.searchByLocation(latitude,longitude, radius, count));
			for(Tweet tweet : results) {
				tweet.setSentimentScore(Analyzer.analyse(tweet.getTweetText()));

			}
			return results;
		}
		
		
		
		//Analyzes Tweets By User Name
		public static ArrayList<Tweet>  AnalyzeTweetsByUser(String username, int count) {
			ArrayList<Tweet> results = new ArrayList<>(TwitterCommunication.searchByUser(username, count));
			for(Tweet tweet : results) {
				tweet.setSentimentScore(Analyzer.analyse(tweet.getTweetText()));
			}
			return results;
		}
		
		
		//Method overloading not used for because AnalyzeTweetsByUser and AnalyzeTweetsByKeyword take in the same type of parameters, but these parameters represent different values.    
  
}
