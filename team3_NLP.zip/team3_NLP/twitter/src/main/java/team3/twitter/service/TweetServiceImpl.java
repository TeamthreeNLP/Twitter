package team3.twitter.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import team3.twitter.model.Result;
import team3.twitter.model.Search;
import team3.twitter.model.Tweet;
import team3.twitter.repository.ResultRepository;
import team3.twitter.repository.TweetRepository;
@Service
public class TweetServiceImpl implements TweetService {
	
@Autowired
private TweetRepository tweetRepository;

@Autowired
private ResultRepository resultRepository;


	@Override
	public List<Tweet> getAllTweets() {
		return tweetRepository.findAll();
		
	}
	


	@Override // Method for retrieving a list of analyzed tweeets and saving them in the database
	public void searchAndAnalyze(Search search) {
		
		List<Tweet> results = null;
		
		if(search.isSearchByUser()) {
			results = App.AnalyzeTweetsByUser(search.getValue(), search.getTweetAmount());
		}
		else results = App.AnalyzeTweetsByKeyword(search.getValue(), search.getTweetAmount());
		
		for(Tweet item : results) {
			this.tweetRepository.save(item);
		}
		
		Result result = new Result(this.getList(search.getTweetAmount()));
        this.resultRepository.save(result);
        
        
	}

	// Retrieves a list of tweets from database for calculating the sentiment score
		public  List<Integer> getList(long amount){
			
		List<Integer>sentimentScoreArray = new ArrayList<>();
		long tweetCount = tweetRepository.count();
		long startingId = tweetCount - amount; 
		List<Tweet> tweetList= new ArrayList<>();
		
		for(long i = startingId ; i < tweetCount ; i++) {
			Tweet tweet =(tweetRepository.findById(i))
					  .orElse(new Tweet());
			tweetList.add(tweet);
		}
		
		for(Tweet tweet : tweetList) {
			sentimentScoreArray.add(tweet.getSentimentScore());
		}	
			return sentimentScoreArray;
	}



		@Override
		public List<Result> getAllResults() {
			return resultRepository.findAll();
		}


	

		
		

}
