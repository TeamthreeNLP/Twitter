package team3.twitter.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import twitter4j.GeoLocation;
@Entity
@Table(name = "results")

public class Result {
	
	
		
	



	

	public Result(List<Integer> list) { 
		
		for(int sentimentScore : list) {
			switch(sentimentScore) {
			case 0:
				this.veryNegative++;
				break;
			case 1:
				this.negative++;
				break;
			case 2:
				this.neutral++;
				break;
			case 3:
				this.positive++;
				break;
			case 4:
				this.veryPositive++;
				break;
			}
			//Calculates sentiment precentages
			int sum = list.stream().mapToInt(Integer::intValue).sum();
			this.average = ((float)sum / list.size());
			this.percentVeryNegative = ((float)this.veryNegative / list.size()) * 100;
            this.percentNegative = ((float)this.negative / list.size()) * 100;
            this.percentNeutral = ((float)this.neutral / list.size()) * 100;
            this.percentPositive = ((float)this.positive / list.size()) * 100;
            this.percentVeryPositive = ((float)this.veryPositive / list.size()) * 100;
			
			
			
		}
		
	}



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id = 0;
	@Column(name = "average")
	private float average;
	@Column(name = "veryPositive")
	private int veryPositive;
	@Column(name = "positive")
	private int positive;
	@Column(name = "neutral")
	private int neutral;
	@Column(name = "negative")
	private int negative;
	@Column(name = "veryNegative")
	private int veryNegative;
	@Column(name = "percentVeryPositive")
	private float percentVeryPositive;
	@Column(name = "percentPositive")
	private float percentPositive;
	@Column(name = "percentNeutral")
	private float percentNeutral;
	@Column(name = "percentNegative")
	private float percentNegative;
	@Column(name = "percentVeryNegative")
	private float percentVeryNegative;
	
	
		
	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	


	public float getAverage() {
		return average;
	}



	public void setAverage(float average) {
		this.average = average;
	}



	public int getVeryPositive() {
		return veryPositive;
	}
	
	public void setVeryPositive(int veryPositive) {
		this.veryPositive = veryPositive;
	}



	public int getPositive() {
		return positive;
	}



	public void setPositive(int positive) {
		this.positive = positive;
	}



	public int getNeutral() {
		return neutral;
	}



	public void setNeutral(int neutral) {
		this.neutral = neutral;
	}



	public int getNegative() {
		return negative;
	}



	public void setNegative(int negative) {
		this.negative = negative;
	}



	public int getVeryNegative() {
		return veryNegative;
	}



	public void setVeryNegative(int veryNegative) {
		this.veryNegative = veryNegative;
	}



	public float getPercentVeryPositive() {
		return percentVeryPositive;
	}



	public void setPercentVeryPositive(float percentVeryPositive) {
		this.percentVeryPositive = percentVeryPositive;
	}



	public float getPercentPositive() {
		return percentPositive;
	}



	public void setPercentPositive(float percentPositive) {
		this.percentPositive = percentPositive;
	}



	public float getPercentNeutral() {
		return percentNeutral;
	}



	public void setPercentNeutral(float percentNeutral) {
		this.percentNeutral = percentNeutral;
	}



	public float getPercentNegative() {
		return percentNegative;
	}



	public void setPercentNegative(float percentNegative) {
		this.percentNegative = percentNegative;
	}



	public float getPercentVeryNegative() {
		return percentVeryNegative;
	}



	public void setPercentVeryNegative(float percentVeryNegative) {
		this.percentVeryNegative = percentVeryNegative;
	}
	public Result() {

}}
