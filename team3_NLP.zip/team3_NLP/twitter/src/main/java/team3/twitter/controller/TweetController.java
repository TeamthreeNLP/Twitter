package team3.twitter.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import team3.twitter.model.Search;
import team3.twitter.model.Tweet;
import team3.twitter.service.TweetService;

@Controller
public class TweetController {
	@Autowired
	private TweetService tweetService;
	
	@GetMapping("/")
public String viewHomePage(Model model) {
	model.addAttribute("listTweets", tweetService.getAllTweets());  //Getting tweet data to display in table
	model.addAttribute("listResults", tweetService.getAllResults()); // Getting result data to display in table
	Search search = new Search();
	model.addAttribute("search", search);
	return "index";
}

	@PostMapping("/saveTweet")
	public String saveTweet(@ModelAttribute("search") Search search ) {
		tweetService.searchAndAnalyze(search); // Calls the searhAndAnalyze function when POST requesr
		return "redirect:/";
	}
	
	


}
