package team3.twitter.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import twitter4j.GeoLocation;
@Entity
@Table(name = "tweets")
public class Tweet {
	
	
	public String getHashtags() {
		return hashtags;
	}

	public void setHashtags(String hashtags) {
		this.hashtags = hashtags;
	}

	public void setId(long id) {
		this.id = id;
	}



	public void setFollowers(int followers) {
		this.followers = followers;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id = 0;
	@Column(name = "author")
	private String author;
	@Column(name = "tweetText" ,length = 500)
	private String tweetText;
	@Column(name = "followers")
	private int followers;
	@Column(name = "sentimentScore")
	private int sentimentScore;
	@Column(name = "hashtags")
	private String hashtags;
	public long getId() {
		return id;
	}
	
	public String getAuthor() {
		return author;
	}
	public String getTweetText() {
		return tweetText;
	}

	public int getFollowers() {
		return followers;
	}
	public String getHashTags() {
		return hashtags;
	}

	public int getSentimentScore() {
		return sentimentScore;
	}
	
	public void setSentimentScore(int sentimentScore) {
		this.sentimentScore = sentimentScore;
	}
	
	
	public Tweet(long id, String author, String tweetText, GeoLocation location, Date time, int followers, String hashtags, int sentimentScore) {
		
		this.id = id;
		this.author = author;
		this.tweetText = tweetText;
		this.followers = followers;
		this.hashtags = hashtags;
		this.sentimentScore = sentimentScore;
			
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}

	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}

	public Tweet() {
		
	}

	
	
}
