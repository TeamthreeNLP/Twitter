package team3.twitter.service;

import java.util.ArrayList;
import java.util.List;

import team3.twitter.model.Result;
import team3.twitter.model.Search;
import team3.twitter.model.Tweet;

public interface TweetService {
List<Tweet> getAllTweets();

List<Result> getAllResults();
public  List<Integer> getList(long amount);

void searchAndAnalyze(Search search);

}
